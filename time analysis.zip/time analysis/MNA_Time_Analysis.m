clear all
close all
clc

Equation=load('MNA_Time.txt');
[xxx,matrixsize]=size(Equation);%dim is the matrix dimension, matrixsize is the size of the MNA matrix
dim=sqrt(matrixsize);

%Build MNA matrix;
MNA=zeros(dim,dim);%initialize a matrix with dim*dim size
for r=1:dim
    for c=1:dim
        MNA(r,c)=Equation(1,(r-1)*dim+c)+Equation(2,(r-1)*dim+c);
    end
end

%RHS_offset matrix: RHS_offset contains the constant_value of current/voltage source in RHS
RHS_offset=zeros(dim,1);
for r=1:dim
    RHS_offset(r)=Equation(3,r);
end

%RHS_coeffient matrix: contains the constant_value of capacitor and inductor in RHC
CL=load('C&L.txt');
[CL_num,xx]=size(CL);% CL_num: number of capacitors/inductors
RHS_coeffi=zeros(dim,1);
for r=1:CL_num
    RHS_coeffi(CL(r,1)+1)=RHS_coeffi(CL(r,1))+CL(r,2);
end


%Let time step=1, V(1,:) is the initial value vector of time1. (in transpose form) 
%We will Show V(2,:),V(3:),V(4:), which is the value vector of time2, time3, time4. 
step_num=4;
V=zeros(step_num,dim);

V(1,:)=[0,-2,-4,0];% This initial value node voltage should be correct case by case!!!!

%Newton-Rapthon
RHS=zeros(dim,1);
for i=2:step_num
    RHS=RHS_offset+ RHS_coeffi .* V(i-1,:)';
    V(i,:)=(pinv(MNA)*RHS)';
end


%OUTPUT
for i=1:step_num
    disp(['Value_vector at time',num2str(i),'=']);
    disp(V(i,:)');
end
