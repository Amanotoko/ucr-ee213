# UCR EE 213 Winter 16

---

This is a repository for final project submission.

---

### Step 1: Fork this repo

In the top-right corner of the page, click **Fork**. 
![fork](https://help.github.com/assets/images/help/repository/fork_button.jpg)

### Step 2: Create a local clone of your fork
```
$ git clone https://github.com/YOUR-USERNAME/ucr-ee213
```

### Step 3: Create your work directory under project/
```
$ mkdir project/YOUR-NETID
```

You can copy the starter-code into your work directory and work on it.
DO NOT change anything elsewhere.

### Step 4: Submit your project

Make sure you didn't change anything outside your work directory.
Click the green button **New Pull Request**.
