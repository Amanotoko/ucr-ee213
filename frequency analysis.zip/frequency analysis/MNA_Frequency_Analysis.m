%Input Data
clear all
close all
clc
Equation=load('MNA_Equation.txt');
[xxx,matrixsize]=size(Equation);%dim is the matrix dimension, matrixsize is the size of the MNA matrix
dim=sqrt(matrixsize);
%Build MNA matrix;
MNA=zeros(dim,dim);%initialize a matrix with dim*dim size
for r=1:dim
    for c=1:dim
        MNA(r,c)=Equation(1,(r-1)*dim+c)+i*Equation(2,(r-1)*dim+c);
    end
end

%Build RHS matrix;
RHS=zeros(dim,1);
for r=1:dim
    RHS(r)=Equation(3,r);
end

%Calculate Value_vector
V=zeros(dim,1);
V=inv(MNA)*RHS;

%Print
MNA
RHS
V